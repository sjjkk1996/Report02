public class Postfix_test {
	public static void main(String[] args) {
		OptExp2 Opt = new OptExp2();
		int result;
		String exp = "35*62/-";
		System.out.printf("결과 : %s", exp);
		result = Opt.evalPostfix(exp);
		System.out.printf("\n결과 = %d \n", result);
	}
}
