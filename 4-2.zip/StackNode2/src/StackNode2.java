class StackNode2 {
	int data;
	StackNode2 link;
}