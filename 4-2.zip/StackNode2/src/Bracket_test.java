public class Bracket_test {
	public static void main(String[] args) {
		OptExp Opt = new OptExp();
		String exp =  "(3*5)-(6/2)";
		
		System.out.println(exp);
		
		if(Opt.testPair(exp))
			System.out.println("괄호 맞음!!!");
		else
			System.out.println("괄호 틀림!!!");
	}

}
