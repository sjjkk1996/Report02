
public class Array_Stack {

	public static void main(String[] args) {
		int stackSize = 5;
		char deletedItem;
		ArrayStack S = new ArrayStack(stackSize);
		
		S.push('A');
		S.printlnStack();
		
		S.push('B');
		S.printlnStack();
		
		S.push('C');
		S.printlnStack();
		
		deletedItem = S.pop();
		if(deletedItem != 0)
			System.out.println("deletedItem : " + deletedItem);
		S.printlnStack();

	}

}
