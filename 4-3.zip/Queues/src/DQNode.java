class DQNode {
	char data;
	DQNode rlink;
	DQNode llink;
}